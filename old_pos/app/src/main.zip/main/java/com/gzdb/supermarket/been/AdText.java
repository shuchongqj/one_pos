package com.gzdb.supermarket.been;

public class AdText {

    /**
     * id : 48
     * varname : pos_index_adv
     * value : 11
     * type : 0
     * info : POS首页广告配置
     */

    private int id;
    private String varname;
    private String value;
    private int type;
    private String info;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getVarname() {
        return varname;
    }

    public void setVarname(String varname) {
        this.varname = varname;
    }

    public String getValue() {
        return value;
    }

    public void setValue(String value) {
        this.value = value;
    }

    public int getType() {
        return type;
    }

    public void setType(int type) {
        this.type = type;
    }

    public String getInfo() {
        return info;
    }

    public void setInfo(String info) {
        this.info = info;
    }
}
