package com.gzdb.supermarket.util;

public class GlobalData {

    public static  String money="";
}
