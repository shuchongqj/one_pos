package com.gzdb.yct.socket.sdk.connection.abilities;

/**
 * Created by xuhao on 2017/5/16.
 */

public interface IConnectable {
    /**
     * 将当前连接管理器发起连接
     */
    void connect();
}
