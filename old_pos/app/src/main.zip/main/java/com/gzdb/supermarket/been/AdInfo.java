package com.gzdb.supermarket.been;

public class AdInfo {

    /**
     * context : 测试一下
     */

    private String context;
    private String url;

    public String getContext() {
        return context;
    }

    public void setContext(String context) {
        this.context = context;
    }

    public String getUrl() {
        return url;
    }

    public void setUrl(String url) {
        this.url = url;
    }
}
