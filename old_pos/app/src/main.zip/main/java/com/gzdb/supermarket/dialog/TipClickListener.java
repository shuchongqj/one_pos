package com.gzdb.supermarket.dialog;

/**
 * Created by zhumg on 2017/3/24 0024.
 */

public interface TipClickListener {
    /** 左为取消，右为确定 */
    public void onClick(boolean left);
}
