package com.gzdb.sale.event;

public class RefreshPriceEvent {
}
