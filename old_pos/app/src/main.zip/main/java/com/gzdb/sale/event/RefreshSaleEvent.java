package com.gzdb.sale.event;

public class RefreshSaleEvent {
}
