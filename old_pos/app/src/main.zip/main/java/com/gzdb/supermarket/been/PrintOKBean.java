package com.gzdb.supermarket.been;

public class PrintOKBean {
    public PrintBean printBean;

    public PrintBean getPrintBean() {
        return printBean;
    }

    public void setPrintBean(PrintBean printBean) {
        this.printBean = printBean;
    }
}
