package com.gzdb.supermarket.been;

import java.util.List;

/**
 * Created by nongyd on 17/6/6.
 */

public class SyncOffOrderResultBean {

    private List<FinishOrderData> datas;

    public List<FinishOrderData> getDatas() {
        return datas;
    }

    public void setDatas(List<FinishOrderData> datas) {
        this.datas = datas;
    }

}
