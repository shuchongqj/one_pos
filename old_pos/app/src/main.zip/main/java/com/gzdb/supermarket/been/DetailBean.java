package com.gzdb.supermarket.been;

public class DetailBean {
  private  String  original_price;//": 300.0,
    private  String item_total_price;//": 290.0,
    private  String item_type_id;//": 5.0,
    private  String item_attr;//": 0.0,
    private  String member_price;//": 280.0,
    private  long group_price;//": 290.0,
    private  String passport_id;//": 1927939.0,
    private  String push_batch_num;//": 1.0,
    private  String business_ratio;//": 0.0,
    private  String id;//": 1524.0,
    private  String barcode;//": "1231231100",
    private  String cost_price;//": 250.0,
    private  String imgs;//": "https://qidianimg.oss-cn-shenzhen.aliyuncs.com/2018/0811/mall_img/15339588950670.png",
    private  String create_time;//": 1.535683839E12,
    private  String item_id;//": 147.0,
    private  String distribution_fee;//": 50.0,
    private  String item_name;//": "卤蛋",
    private  String order_sequence_number;//": "201808311927939105039779",
    private  String platform_ratio;//": 0.0,
    private  String distribution_address;//": "湖南省长沙市市辖区hhjj",
    private  String name;//": "卤蛋",
    private  String reward_gold;//": 0.0,
    private  int normal_quantity;//": 1.0,
    private  String distribution_type;//": 1.0,
    private  String order_id;//": 937.0

    public String getOriginal_price() {
        return original_price;
    }

    public void setOriginal_price(String original_price) {
        this.original_price = original_price;
    }

    public String getItem_total_price() {
        return item_total_price;
    }

    public void setItem_total_price(String item_total_price) {
        this.item_total_price = item_total_price;
    }

    public String getItem_type_id() {
        return item_type_id;
    }

    public void setItem_type_id(String item_type_id) {
        this.item_type_id = item_type_id;
    }

    public String getItem_attr() {
        return item_attr;
    }

    public void setItem_attr(String item_attr) {
        this.item_attr = item_attr;
    }

    public String getMember_price() {
        return member_price;
    }

    public void setMember_price(String member_price) {
        this.member_price = member_price;
    }

    public long getGroup_price() {
        return group_price;
    }

    public void setGroup_price(long group_price) {
        this.group_price = group_price;
    }

    public String getPassport_id() {
        return passport_id;
    }

    public void setPassport_id(String passport_id) {
        this.passport_id = passport_id;
    }

    public String getPush_batch_num() {
        return push_batch_num;
    }

    public void setPush_batch_num(String push_batch_num) {
        this.push_batch_num = push_batch_num;
    }

    public String getBusiness_ratio() {
        return business_ratio;
    }

    public void setBusiness_ratio(String business_ratio) {
        this.business_ratio = business_ratio;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getBarcode() {
        return barcode;
    }

    public void setBarcode(String barcode) {
        this.barcode = barcode;
    }

    public String getCost_price() {
        return cost_price;
    }

    public void setCost_price(String cost_price) {
        this.cost_price = cost_price;
    }

    public String getImgs() {
        return imgs;
    }

    public void setImgs(String imgs) {
        this.imgs = imgs;
    }

    public String getCreate_time() {
        return create_time;
    }

    public void setCreate_time(String create_time) {
        this.create_time = create_time;
    }

    public String getItem_id() {
        return item_id;
    }

    public void setItem_id(String item_id) {
        this.item_id = item_id;
    }

    public String getDistribution_fee() {
        return distribution_fee;
    }

    public void setDistribution_fee(String distribution_fee) {
        this.distribution_fee = distribution_fee;
    }

    public String getItem_name() {
        return item_name;
    }

    public void setItem_name(String item_name) {
        this.item_name = item_name;
    }

    public String getOrder_sequence_number() {
        return order_sequence_number;
    }

    public void setOrder_sequence_number(String order_sequence_number) {
        this.order_sequence_number = order_sequence_number;
    }

    public String getPlatform_ratio() {
        return platform_ratio;
    }

    public void setPlatform_ratio(String platform_ratio) {
        this.platform_ratio = platform_ratio;
    }

    public String getDistribution_address() {
        return distribution_address;
    }

    public void setDistribution_address(String distribution_address) {
        this.distribution_address = distribution_address;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getReward_gold() {
        return reward_gold;
    }

    public void setReward_gold(String reward_gold) {
        this.reward_gold = reward_gold;
    }

    public int getNormal_quantity() {
        return normal_quantity;
    }

    public void setNormal_quantity(int normal_quantity) {
        this.normal_quantity = normal_quantity;
    }

    public String getDistribution_type() {
        return distribution_type;
    }

    public void setDistribution_type(String distribution_type) {
        this.distribution_type = distribution_type;
    }

    public String getOrder_id() {
        return order_id;
    }

    public void setOrder_id(String order_id) {
        this.order_id = order_id;
    }
}
