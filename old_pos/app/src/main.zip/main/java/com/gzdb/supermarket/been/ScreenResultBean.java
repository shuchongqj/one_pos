package com.gzdb.supermarket.been;

import java.util.List;

/**
 * Created by nongyd on 17/9/6.
 */

public class ScreenResultBean {

    private List<SettingMainImgBean> datas;

    public List<SettingMainImgBean> getDatas() {
        return datas;
    }

    public void setDatas(List<SettingMainImgBean> datas) {
        this.datas = datas;
    }

}
