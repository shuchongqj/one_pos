package com.gzdb.supermarket.been;

public class MenuIconBean {

    private  String proName;
    private  String bgColors;
    private  int images;

    public String getProName() {
        return proName;
    }

    public void setProName(String proName) {
        this.proName = proName;
    }

    public String getBgColors() {
        return bgColors;
    }

    public void setBgColors(String bgColors) {
        this.bgColors = bgColors;
    }

    public int getImages() {
        return images;
    }

    public void setImages(int images) {
        this.images = images;
    }
}
