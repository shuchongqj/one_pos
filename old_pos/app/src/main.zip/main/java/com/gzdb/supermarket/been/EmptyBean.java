package com.gzdb.supermarket.been;

/**
 * Created by nongyd on 17/5/31.
 */

public class EmptyBean {
}
