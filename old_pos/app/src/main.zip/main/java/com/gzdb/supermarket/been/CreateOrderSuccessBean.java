package com.gzdb.supermarket.been;

/**
 * Created by nongyd on 17/6/1.
 */

public class CreateOrderSuccessBean {

    /**
     * orderId : 100552
     */

    private String orderId;

    public String getOrderId() {
        return orderId;
    }

    public void setOrderId(String orderId) {
        this.orderId = orderId;
    }
}
