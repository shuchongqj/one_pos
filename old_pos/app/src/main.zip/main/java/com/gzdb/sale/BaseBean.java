package com.gzdb.sale;

/**
 * Created by yunshi on 2017/11/20.
 */

public class BaseBean {
}
