package com.gzdb.supermarket.been;

public class LoginCodeBean {

    /**
     * key : B1A6CE59A07E59C5681E6D3397482B99
     */
    private String key;

    public String getKey() {
        return key;
    }

    public void setKey(String key) {
        this.key = key;
    }
}
