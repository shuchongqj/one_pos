package com.gzdb.supermarket.event;

public class RefreshEvent {
}
